    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
      <section class="panel__content">
        <h2>
          حساب کاربری
        </h2>
        <div class="panel__body">
          <ul class="dashboard">
            <li>
              نام و نام خانوادگی
              <span><?php echo $current_user->display_name ?></span>
            </li>
            <li>
              ایمیل
              <span><?php echo $current_user->user_email ?></span>
            </li>
            <li>
              تاریخ عضویت
              <span><?php echo wp_date('d M Y', strtotime($current_user->user_registered)); ?></span>
            </li>
          </ul>
          <a class="edit_profile" href="<?php bloginfo('url') ?>/panel?action=edit" id="">
            <i class="bi bi-pencil"></i>
            ویرایش اطلاعات کاربری
          </a>
          <!-- <?php echo do_shortcode('[purchase_history]') ?> -->
        </div>
      </section>
    </div>