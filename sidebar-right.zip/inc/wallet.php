    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
      <section class="panel__content">
        <h2>
          کیف پول
        </h2>
        <div class="panel__body">
          <div class="my-2 d-block">
            موجودی فعلی کیف پول: <?= do_shortcode('[edd_wallet_value]'); ?>
          </div>
          <?php echo do_shortcode('[edd_deposit]') ?>
        </div>
      </section>

    </div>