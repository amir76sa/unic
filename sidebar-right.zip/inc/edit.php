    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
      <section class="panel__content">
        <h2>
          ویرایش پروفایل
        </h2>
        <div class="panel__body">

          <?php echo do_shortcode('[edd_profile_editor]') ?>
        </div>
      </section>

    </div>