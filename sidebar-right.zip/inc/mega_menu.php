<?php
// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  // Set a unique slug-like ID
  $prefix = '_prefix_menu_options';

  // Create profile options
  CSF::createNavMenuOptions( $prefix, array(
    'data_type' => 'unserialize',
  ) );

  // Create a section
  CSF::createSection( $prefix, array(
    'fields' => array(

      // array(
      //   'id'    => 'icon',
      //   'type'  => 'icon',
      //   'title' => 'Icon',
      // ),

      array(
        'id'    => 'has_mega_menu',
        'type'  => 'switcher',
        'title' => 'مگامنو',
        'desc' => 'اگر میخواهید این منو مگامنو باشد فعال کنید.
        <br><br>
        همواره منوی با عمق ۱ را برای مگامنو انتخاب کنید و از فعال کردن این گزینه در زیرمنو ها خودداری کنید.
        '
      ),

      array(
        'id'       => 'mega_menu_width',
        'type'     => 'dimensions',
        'height'   => false,
        'title'    => 'اندازه طول مگامنو',
        'dependency' => array( 
          'has_mega_menu', '==', 'true',
         ),
        'default'  => array(
          'width'  => '500',
          'height' => 'auto',
          'unit'   => 'px',
        ),
      ),

      array(
        'id'    => 'mega_menu_child',
        'type'  => 'text',
        'title' => 'شورتکد المنتوری مگامنو',
        'dependency' => array( 'has_mega_menu', '==', 'true' ),
        'desc'  => 'از بخش قالب های ذخیره شده المنتور شرت کد صفحه ساخته شده با المنتور را جهت نمایش انتخاب کنید.'
      ),

    )
  ) );

}