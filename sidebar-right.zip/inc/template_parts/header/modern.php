<header class="header header_modern">
  <div class="container px-5">
    <div class="d-flex fix_mobile_modern">
      <a href="<?php echo site_url() ?>">
        <div class="logo">
          <?php if ($GLOBALS['config']['logo_image']['url']) : ?>
            <img class="desktop_logo" src="<?= $GLOBALS['config']['logo_image']['url']; ?>" alt="<?php bloginfo('name'); ?>">
            <img class="mobile_logo" src="<?= $GLOBALS['config']['logo_image_mobile']['url']; ?>" alt="<?php bloginfo('name'); ?>">
          <?php else : ?>
            <img class="desktop_logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="<?php bloginfo('name'); ?>">
            <img class="mobile_logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo_mobile.png" alt="<?php bloginfo('name'); ?>">
          <?php endif; ?>
        </div><!-- /.logo -->
      </a>
      <div class="heading_left d-flex">
        <div class="heading_left__top mt-4 mb-3 h-100 d-flex justify-content-between align-items-center">
          <div class="modern_mini_cat">
            <?php if( theme_options('modern_mini_cat') ): foreach( theme_options('modern_mini_cat') as $item ): ?>
              <a href="<?php echo $item['link'] ?>">
                <img src="<?php echo $item['icon']['url'] ?>" alt="<?php echo $item['name'] ?>">
                <strong><?php echo $item['name'] ?></strong>
              </a>
            <?php endforeach; endif;  ?>

          </div>
          <div class="cta">
            <ul>
              <div class="darkMode">
              <i class="bi bi-sun dark_toggle"></i>
              </div>
            <?php
              if ($GLOBALS['config']['show_profile'] == 'true') :
                if (!is_user_logged_in()) { ?>
                  <li>
                    <a href="#registerModal" data-bs-toggle="modal" data-bs-target="#registerModal">
                      ورود/عضویت
                    </a>
                  </li>
                <?php } else { ?>
                  <li>
                    <a href="<?php bloginfo('url') ?>/panel">
                      پنل کاربری
                    </a>
                  </li>
              <?php }
              endif; ?>
              <?php if ( $GLOBALS['config']['show_cart'] == 'true' && function_exists('EDD') ) : ?>
                <li>
                  <a href="<?php bloginfo('url') ?>/cart">
                    سبد خرید
                  </a>
                  <span class="badge edd-cart-quantity"><?php echo edd_get_cart_quantity(); ?></span>
                </li>
              <?php endif; ?>
            </ul>
          </div>
        </div><!-- /.heading_left__top -->
        <div class="heading_left__bottom d-flex justify-content-between align-items-center">
          <div class="search">
            <a class="search_triger" href="#search">
              <i class="bi bi-search"></i>
              جستجو کنید...
            </a>
          </div>
          <div>
            <nav class="navigation">
              <ul>
                <?php
                $menuLocations = get_nav_menu_locations();
                $menuID = $menuLocations['main-menu'];
                $primaryNav = wp_get_nav_menu_items($menuID);
                foreach ($primaryNav as $item) :
                  $icon = get_field('icon', $item);
                ?>
                  <li>
                    <a href="<?= $item->url; ?>">
                      <?= $item->title; ?>
                    </a>
                  </li>
                <?php endforeach; ?>
              </ul>
            </nav>
            <div class="mobileNavBtn">
              <i class="bi bi-list"></i>
            </div>
          </div>
        </div><!-- /.heading_left__bottom -->
      </div><!-- /.heading_left -->
    </div>
  </div><!-- /.container -->
</header>