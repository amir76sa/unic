<header class="header header_default">
  <div class="container d-flex justify-content-between align-items-center px-4">
    <div class="mobileNavBtn">
      <i class="bi bi-list"></i>
    </div>
    <div class="rightSide">
      <a href="<?php bloginfo('url'); ?>">
        <div class="logo">
          <?php if ($GLOBALS['config']['logo_image']['url']) : ?>
            <img class="desktop_logo" src="<?= $GLOBALS['config']['logo_image']['url']; ?>" alt="<?php bloginfo('name'); ?>">
            <img class="mobile_logo" src="<?= $GLOBALS['config']['logo_image_mobile']['url']; ?>" alt="<?php bloginfo('name'); ?>">
          <?php else : ?>
            <img class="desktop_logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="<?php bloginfo('name'); ?>">
            <img class="mobile_logo" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo_mobile.png" alt="<?php bloginfo('name'); ?>">
          <?php endif; ?>
          <span><?= $GLOBALS['config']['logo_text']; ?></span>
        </div>
      </a>
      <div class="darkMode">
        <i class="bi bi-sun dark_toggle"></i>
      </div>
    </div>
    <div class="leftSide">
    <div class="mobile_nav_search">
      <i class="bi bi-search"></i>
    </div>
      <nav class="navigation">
        <ul>
          <?php
          $menuLocations = get_nav_menu_locations();
          $menuID = $menuLocations['main-menu'];
          $primaryNav = wp_get_nav_menu_items($menuID);
          foreach ($primaryNav as $item) :
            $icon = get_field('icon', $item);
          ?>
            <li>
              <a href="<?= $item->url; ?>">
                <i class="bi bi-<?= $icon; ?>"></i>
                <?= $item->title; ?>
              </a>
            </li>
          <?php endforeach; ?>
          <li>
            <a class="search_triger" href="#search">
              <i class="bi bi-search"></i>
              جستجو
            </a>
          </li>
          <?php
          if ($GLOBALS['config']['show_profile'] == 'true') :
            if (!is_user_logged_in()) { ?>
              <li>
                <a href="#registerModal" data-bs-toggle="modal" data-bs-target="#registerModal">
                  <i class="bi bi-person-circle"></i>
                  ورود/عضویت
                </a>
              </li>
            <?php } else { ?>
              <li>
                <a href="<?php bloginfo('url') ?>/panel">
                  <i class="bi bi-people"></i>
                  پنل کاربری
                </a>
              </li>
          <?php }
          endif; ?>
          <?php if ( $GLOBALS['config']['show_cart'] == 'true' && function_exists('EDD') ) : ?>
            <li>
              <a href="<?php bloginfo('url') ?>/cart">
                <i class="bi bi-basket"></i>
                سبد خرید
              </a>
              <span class="badge edd-cart-quantity"><?php echo edd_get_cart_quantity(); ?></span>
            </li>
          <?php endif; ?>
        </ul>
      </nav>
      
    </div>
  </div>
</header>