<footer class="footer">
  <div class="container--home footer_container pt-3">
    <div class="footer__logo">
      <div class="logo">
        <?php if ($GLOBALS['config']['logo_image']['url']) : ?>
          <img src="<?= $GLOBALS['config']['logo_image']['url']; ?>" alt="<?php bloginfo('url'); ?>">
        <?php else : ?>
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="<?php bloginfo('url'); ?>">
        <?php endif; ?>
      </div>
    </div>
    <?php if ($GLOBALS['config']['footer_nav_active'] == 'true') : ?>
      <nav class="footer__nav">
        <?php wp_nav_menu(array('theme_location' => 'footer-menu', 'container' => '', 'menu_class' => 'menunav')); ?>
      </nav>
    <?php endif; ?>
    <div class="container">
      <div class="row mt-4">
        <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-4 col-sm-6 mb-2">
          <seciton class="footer_widget">
            <div class="footer_heading">
              <h4>درباره ما</h4>
            </div>
            <p><?= $GLOBALS['config']['about']; ?></p>
          </seciton>
        </div>
        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-3 col-sm-3 mb-2">
          <seciton class="footer_widget">
            <div class="footer_heading">
              <?php
              $footer1_title = $GLOBALS['config']['footer_menu_1_title'];
              ?>
              <h4><?= $footer1_title ?></h4>
            </div>
            <ul>
              <?php foreach ($GLOBALS['config']['footer_menu_1'] as $item) : ?>
                <li>
                  <a href="<?= $item['link'] ?>"><?= $item['name'] ?></a>
                </li>
              <?php endforeach; ?>
            </ul>
          </seciton>
        </div>

        <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-3 col-sm-3 mb-2">
          <seciton class="footer_widget">
            <div class="footer_heading">
              <?php
              $footer2_title = $GLOBALS['config']['footer_menu_2_title'];
              ?>
              <h4><?= $footer2_title ?></h4>
            </div>
            <ul>
              <?php foreach ($GLOBALS['config']['footer_menu_2'] as $item) : ?>
                <li>
                  <a href="<?= $item['link'] ?>"><?= $item['name'] ?></a>
                </li>
              <?php endforeach; ?>
            </ul>
          </seciton>
        </div>

        <div class="col-xxl-2 col-xl-2 col-lg-6 col-md-6 col-sm-6 mb-2">
          <seciton class="footer_widget">
            <div class="footer_heading">
              <?php
              $footer3_title = $GLOBALS['config']['footer_menu_3_title'];
              ?>
              <h4><?= $footer3_title ?></h4>
            </div>
            <ul>
              <?php foreach ($GLOBALS['config']['footer_menu_3'] as $item) : ?>
                <li>
                  <a href="<?= $item['link'] ?>"><?= $item['name'] ?></a>
                </li>
              <?php endforeach; ?>
            </ul>
          </seciton>
        </div>
        <div class="col-xxl-3 col-xl-3 col-lg-6 col-sm-6 mb-2">
          <seciton class="footer_widget">
            <div class="footer_heading">
              <h4>مارا درشبکه های اجتماعی دنبال کنید</h4>
            </div>
            <?php if ($GLOBALS['config']['stats_active'] == 'true') : ?>
              <div class="stats">
                <ul>
                  <li>
                    <span><?= wp_count_posts()->publish; ?>+</span>
                    مطلب منتشر شده
                  </li>
                  <li>
                    <span> <?= wp_count_comments()->approved; ?>+</span>
                    دیدگاه ثبت شده
                  </li>
                  <li>
                    <span><?= count_users()['total_users']; ?>+</span>
                    کاربر خوشحال
                  </li>
                </ul>
              </div>
            <?php endif; ?>
            <div class="footer_social">
              <ul>
                <?php if ($GLOBALS['config']['instagram']) : ?>
                  <li>
                    <a class="instagram" href="<?= $GLOBALS['config']['instagram'] ?>"><i class="bi bi-instagram"></i> اینستاگرام</a>
                  </li>
                <?php endif; ?>
                <?php if ($GLOBALS['config']['telegram']) : ?>
                  <li>
                    <a class="telegram" href="<?= $GLOBALS['config']['telegram'] ?>"><i class="bi bi-telegram"></i> تلگرام</a>
                  </li>
                <?php endif; ?>
                <?php if ($GLOBALS['config']['facebook']) : ?>
                  <li>
                    <a aria-label="facebook" role="link" href="<?= $GLOBALS['config']['facebook'] ?>"><i class="bi bi-facebook"></i></a>
                  </li>
                <?php endif; ?>
                <?php if ($GLOBALS['config']['twitter']) : ?>
                  <li>
                    <a aria-label="twitter" role="link" href="<?= $GLOBALS['config']['twitter'] ?>"><i class="bi bi-twitter"></i></a>
                  </li>
                <?php endif; ?>
              </ul>
            </div>
          </seciton>
        </div>
      </div>
    </div>
    <div class="row mt-5">
      <div class="container copyright">
        <?= $GLOBALS['config']['copyright']; ?>
      </div>

    </div>
  </div>
</footer>