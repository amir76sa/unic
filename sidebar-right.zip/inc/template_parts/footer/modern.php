<div class="footer modern">
  <div class="footer_top">
    <a title="فارسروید" href="<?php the_permalink(); ?>">
      <?php if ($GLOBALS['config']['logo_image']['url']) : ?>
        <img src="<?= $GLOBALS['config']['logo_image']['url']; ?>" alt="<?php bloginfo('url'); ?>">
      <?php else : ?>
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="<?php bloginfo('url'); ?>">
      <?php endif; ?>
    </a>
  </div>

  <div class="container">
    <div class="footer_row mt-5">
      <div class="post_update">
        <div class="post_update__head d-flex justify-content-between">
          <div class="title">
            <i class="bi <?php echo $GLOBALS['config']['post_update_icon_1'] ?>"></i>
            <?php echo $GLOBALS['config']['post_update_title_1'] ?>
          </div>

          <div class="stats">
            <?php 
            $post_count = unique_get_today_posts_count( $GLOBALS['config']['post_update_content_1'][0] );
            if( $post_count !== 0 ):
            ?>
            <span>
              <?php echo $post_count; ?>
            </span>
            مورد جدید امروز افزوده شد.
            <?php else: ?>
            متاسفانه امروز مطلبی جدیدی نداشتیم.
            <?php endif; ?>
          </div>
        </div>
        <div class="swiper vertical_swiepr position-relative">
          <div class="swiper-wrapper">
            <?php 
            $args = array(
              'posts_per_page' => 15,
              'cat'            => $GLOBALS['config']['post_update_content_1'][0]
            );

            $query = new WP_Query($args);
            if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
            ?>
            <div class="swiper-slide">
              <a href="<?php the_permalink(); ?>">
                <span class="text-truncate"><?php echo limited_excerpt( get_field('faName'), 40) ?></span>
                <span class="text-truncate"><?php echo limited_excerpt( get_field('enName'), 40) ?></span>
              </a>
            </div>
            <?php endwhile;
            endif;
            wp_reset_postdata(); ?>
          <!-- If we need navigation buttons -->
          <!-- <div class="swiper-button-prev"></div>
          <div class="swiper-button-next"></div> -->
          </div>
           

        </div>
      </div>
      <div class="about">
        <p><?= $GLOBALS['config']['about']; ?></p>


        <?php if ($GLOBALS['config']['stats_active'] == 'true') : ?>
        <div class="stats mt-3">
          <ul>
            <li>
              <span><?= wp_count_posts()->publish; ?>+</span>
              مطلب منتشر شده
            </li>
            <li>
              <span> <?= wp_count_comments()->approved; ?>+</span>
              دیدگاه ثبت شده
            </li>
            <li>
              <span><?= count_users()['total_users']; ?>+</span>
              کاربر خوشحال
            </li>
          </ul>
        </div>
      <?php endif; ?>

        <?php if ($GLOBALS['config']['footer_nav_active'] == 'true') : ?>
          <nav class="footer__nav">
            <?php wp_nav_menu(array('theme_location' => 'footer-menu', 'container' => '', 'menu_class' => 'menunav')); ?>
          </nav>
        <?php endif; ?>


      </div>
      <div class="post_update">
        <div class="post_update__head d-flex justify-content-between">
          <div class="title">
            <i class="bi <?php echo $GLOBALS['config']['post_update_icon_2'] ?>"></i>
            <?php echo $GLOBALS['config']['post_update_title_2'] ?>
          </div>

          <div class="stats">
            <?php 
            $post_count = unique_get_today_posts_count( $GLOBALS['config']['post_update_content_2'][0] );
            if( $post_count !== 0 ):
            ?>
            <span>
              <?php echo $post_count; ?>
            </span>
            مورد جدید امروز افزوده شد.
            <?php else: ?>
            متاسفانه امروز مطلبی جدیدی نداشتیم.
            <?php endif; ?>
          </div>
        </div>
        <div class="swiper vertical_swiepr position-relative">
          <div class="swiper-wrapper">
              <?php 
              $args = array(
                'posts_per_page' => 15,
                'cat'            => $GLOBALS['config']['post_update_content_2'][0]
              );

              $query = new WP_Query($args);
              if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
              ?>
              <div class="swiper-slide">
                <a href="<?php the_permalink(); ?>">
                <span class="text-truncate"><?php echo limited_excerpt( get_field('faName'), 40) ?></span>
                <span class="text-truncate"><?php echo limited_excerpt( get_field('enName'), 40) ?></span>
                </a>
              </div>
              <?php endwhile;
              endif;
              wp_reset_postdata(); ?>
              <!-- If we need navigation buttons -->
              <!-- <div class="swiper-button-prev"></div>
              <div class="swiper-button-next"></div> -->
            </div>
          
        </div>
      </div>
    </div>

    <div class="text-center mt-5 footer_social">
    <strong>ما را در شبکه های اجتماعی دنبال کنید.</strong>

    <ul>
      <?php if ($GLOBALS['config']['instagram']) : ?>
        <li>
          <a class="instagram" href="<?= $GLOBALS['config']['instagram'] ?>"><i class="bi bi-instagram"></i></a>
        </li>
      <?php endif; ?>
      <?php if ($GLOBALS['config']['telegram']) : ?>
        <li>
          <a class="telegram" href="<?= $GLOBALS['config']['telegram'] ?>"><i class="bi bi-telegram"></i></a>
        </li>
      <?php endif; ?>
      <?php if ($GLOBALS['config']['facebook']) : ?>
        <li>
          <a aria-label="facebook" role="link" href="<?= $GLOBALS['config']['facebook'] ?>"><i class="bi bi-facebook"></i></a>
        </li>
      <?php endif; ?>
      <?php if ($GLOBALS['config']['twitter']) : ?>
        <li>
          <a aria-label="twitter" role="link" href="<?= $GLOBALS['config']['twitter'] ?>"><i class="bi bi-twitter"></i></a>
        </li>
      <?php endif; ?>
    </ul>
  </div>

  <div class="text-center copyright_new mt-5">
    <?php echo $GLOBALS['config']['copyright'] ?>
  </div>

  </div>
</div>