<?php /* Custom Styles */

function css_styles(){
  ?>
<style>
  html{
    --primaryColor: <?= $GLOBALS['config']['theme_color']; ?>;
    --primaryColorLight: <?= $GLOBALS['config']['theme_color']; ?>ad;
  }
    .header .darkMode {
      color: <?= $GLOBALS['config']['theme_color']; ?>
    }

    .header .navigation ul li .badge {
      background: <?= $GLOBALS['config']['theme_color']; ?>
    }

    .header .navigation ul li:hover {
    }

    .ads_blockk a:hover {
      color: <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .sidebar .widget .widget__title h3 {
      border-bottom: 2px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .sidebar .widget .widget__body .widget__card a:hover .h2,
    .sidebar .widget .widget__body .widget__card a:hover h2 {
      color: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    .small_post .nav-tabs .nav-item.show .nav-link,
    .small_post .nav-tabs .nav-link.active {
      color: <?= $GLOBALS['config']['theme_color']; ?>;
      border-bottom: 2px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .text_ads a:hover {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }

    .footer .footer_widget li a:hover {
      color: <?= $GLOBALS['config']['theme_color']; ?>;
    }


    .header .mobileNavBtn {
      color: <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .go_up {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;

    }

    .edd_purchase_submit_wrapper #edd-purchase-button,
    .edd_purchase_submit_wrapper .edd-add-to-cart,
    .edd_purchase_submit_wrapper .edd-submit,
    .edd_purchase_submit_wrapper .edd_go_to_checkout {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;

    }

    .gallery .swiper-scrollbar-drag {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;

    }

    .single_post header .h1,
    .single_post header h1 {
      border-bottom: 2px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .cat_header .h3,
    .cat_header h3 {
      border-bottom: 2px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .latestPosts2 .latestPosts2__right .latestPosts2__title .h2,
    .latestPosts2 .latestPosts2__right .latestPosts2__title h2 {
      color: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    .latestPosts2 .latestPosts2__right .latestPosts2__download .latestPosts2__download--link {
      color: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }

    .latestPosts2 .latestPosts2__right .latestPosts2__download .latestPosts2__download--link:hover {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
      color: #fff !important;
    }

    .latestPosts .latestPosts__right .latestPosts__download .latestPosts__download--link {
      color: <?= $GLOBALS['config']['theme_color']; ?> !important;

    }

    .latestPosts .latestPosts__right .latestPosts__download .latestPosts__download--link:hover {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
      color: #fff !important;

    }

    .latestPostsOld .latestPostsOld__download .latestPostsOld__download--link {
      color: <?= $GLOBALS['config']['theme_color']; ?> !important;

    }

    .latestPostsOld .latestPostsOld__download .latestPostsOld__download--link:hover {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
      color: #fff !important;

    }

    .single_info .download_single {
      background: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    .single_category .current-post-parent a {
      color: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    .single_category .current-post-parent {
      border: 1px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .single_category .current-post-parent .sub-menu li:first-child {
      border-top: 1px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    .single_category .sub-menu .current-post-ancestor a {
      color: <?= $GLOBALS['config']['theme_color']; ?>
    }

    #download_box .nav-dl.active {
      background: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    #download_box .dltab-content {
      border-right: 3px solid <?= $GLOBALS['config']['theme_color']; ?>;
    }

    #download_box .dl-pane .download_item i {
      background: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    #download_box .dl-pane .download_item a:hover {
      background: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    #download_box .info_box .password {

      background: <?= $GLOBALS['config']['theme_color']; ?>;
      border-bottom: none;
    }

    #download_box .info_box .password:hover {

      background: <?= $GLOBALS['config']['theme_color']; ?>;
      border-bottom: none;
    }

    .single_post .comments .comment-reply-link,
    .single_post .comments .submit-btn {
      background: <?= $GLOBALS['config']['theme_color']; ?>;

    }

    .edd-submit.button.blue:hover {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }

    .edd-submit.button.blue {
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    #registerModal .rightSide{
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    #registerModal .edd-submit{
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    #registerModal .dismiss{
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    #registerModal .nav-link{
      color: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    .single_info .download_single:hover{
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
      border-color: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    .single_post_text a{
      color: <?= $GLOBALS['config']['theme_color']; ?> !important;
      font-weight: 300;
    }
    .top_badge{
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
    }
    .dev_cta a:hover{
      background: <?= $GLOBALS['config']['theme_color']; ?> !important;
      color: #fff;
    }
  </style>
  <?php
}

add_action('wp_head', 'css_styles', 100);