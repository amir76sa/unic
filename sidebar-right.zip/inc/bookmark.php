    <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6">
      <section class="panel__content">
        <h2>
          لیست علاقه مندی
        </h2>
        <div class="panel__body">
          <div class="row">
            <?php
            $favorites_list = get_user_meta($current_user->ID, 'favorites_list', true);
            if ($favorites_list) :
              $args = array(
                'post__in' => $favorites_list,
                'orderby' => 'post__in',
                'post_status' => 'publish',
                'post_type' => 'post',
                'showposts' => -1
              );

              $posts = new WP_Query($args);

              if ($posts->have_posts()) :
                while ($posts->have_posts()) {
                  $posts->the_post(); ?>
                  <div class="col-xxl-3 col-xl-3 col-lg-3 col-sm-4 col-md-4 col-6 p<?php echo $post->ID; ?>">
                    <div class="posts">
                      <a href="<?php the_permalink() ?>">
                        <div>
                          <?php the_post_thumbnail('single'); ?>
                        </div>
                        <?php the_title(); ?>
                      </a>
                      <div data-bs-toggle="tooltip" data-bs-placement="top" title="حذف از لیست علاقه مندی" class="removeFav" data-user="<?php echo get_current_user_id(); ?>" data-id="<?php echo $post->ID ?>">
                        <i class="bi bi-trash"></i>
                      </div>
                    </div>
                  </div>
              <?php }
              endif;
            else : ?>
              <div class="text-center p-5">
                <h6>لیست علاقه مندی خالی می‌باشد.</h6>
                <span style="font-weight: 100; font-size:14px">بازی یا برنامه های های مورد علاقه خود را به این لیست اضافه کنید.</span>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>

    </div>