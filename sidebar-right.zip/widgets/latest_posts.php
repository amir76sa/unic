<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class LatestPosts_widget extends \Elementor\Widget_Base
{

  /**
   * Get widget name.
   *
   * Retrieve oEmbed widget name.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget name.
   */
  public function get_name()
  {
    return 'latestPosts';
  }

  /**
   * Get widget title.
   *
   * Retrieve oEmbed widget title.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget title.
   */
  public function get_title()
  {
    return esc_html__('ویجت آخرین مطالب استایل #1', 'elementor-ads-widget');
  }

  /**
   * Get widget icon.
   *
   * Retrieve oEmbed widget icon.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget icon.
   */
  public function get_icon()
  {
    return 'eicon-post-content';
  }

  /**
   * Get custom help URL.
   *
   * Retrieve a URL where the user can get more information about the widget.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget help URL.
   */
  public function get_custom_help_url()
  {
    return 'https://developers.elementor.com/docs/widgets/';
  }

  /**
   * Get widget categories.
   *
   * Retrieve the list of categories the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget categories.
   */
  public function get_categories()
  {
    return ['basic'];
  }

  /**
   * Get widget keywords.
   *
   * Retrieve the list of keywords the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget keywords.
   */
  public function get_keywords()
  {
    return ['post', 'latestpost', 'index'];
  }

  /**
   * Register oEmbed widget controls.
   *
   * Add input fields to allow the user to customize the widget settings.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function register_controls()
  {

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('تنظیمات بلاک آخرین مطالب استایل #1', 'elementor-ads-widget'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $options = array();

    $args = array(
      'hide_empty' => false,
      'post_type'     => 'post',
      'taxonomy'  => 'category',

    );

    $categories = get_categories($args);

    foreach ($categories as $key => $category) {
      $options[$category->term_id] = $category->name;
    }


    $this->add_control(
      'title',
      [
        'label' => esc_html__('عنوان بلاک', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا آخرین مطالب', 'elementor-oembed-widget'),
        'default' => 'آخرین مطالب'
      ]
    );

    $this->add_control(
      'category',
      [
        'label' => esc_html__('انتخاب دسته بندی', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'multiple' => false,
        'options' => $options,
        'default' => [],
      ]
    );

    $this->add_control(
      'number_posts',
      [
        'label' => esc_html__('تعداد مطالب برای نمایش', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا ۱۰', 'elementor-oembed-widget'),
      ]
    );

    $this->add_control(
      'pagination',
      [
        'label' => esc_html__('فعال بودن صفحه بندی', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__('بله', 'your-plugin'),
        'label_off' => esc_html__('خیر', 'your-plugin'),
        'return_value' => true,
        'default' => true,
      ]
    );


    $this->end_controls_section();
  }

  /**
   * Render oEmbed widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function render()
  {
    $settings = $this->get_settings_for_display();
    $pagination = $settings['pagination'];
    $number_posts = $settings['number_posts'];
    $title = $settings['title'];
    $cat_id = $settings['category'];
    if (!empty($cat_id)) {
      $paged = (get_query_var('page')) ? get_query_var('page') : 1;
      $cat_name = get_cat_name($settings['category']);
      $args = array(
        'post_type' => 'post',
        'posts_per_page' => $number_posts,
        'cat' => $cat_id,
        'order' => 'DESC',
        'paged' => $paged,
      );
    } else {
      $paged = (get_query_var('page')) ? get_query_var('page') : 1;
      $args = array(
        'post_type' => 'post',
        'posts_per_page' => $number_posts,
        'order' => 'DESC',
        'paged' => $paged,
      );
    }
?>

    <div class="latestPosts">
      <h3 class="latestPosts__heading"><?php echo $title; ?></h3>
      <?php
      $query = new WP_Query($args);
      if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
      ?>
          <div class="row g-3 mb-sm-3 mb-5">
            <div class="col-xxl-9 col-xl-9 col-lg-9 col-md-9 col-sm-8 order-2 order-sm-1 m-0 my-sm-2">
              <div class="latestPosts__right">
                <header class="latestPosts__header">
                  <div class="latestPosts__rating">
                    <strong><?php the_field('post_score'); ?></strong>
                    <div class="Stars" style="--rating: <?php the_field('post_score'); ?>;" role="img" aria-label="Rating of this product is 2.3 out of 5."></div>
                  </div>
                  <div class="latestPosts__title">
                    <a href="<?php the_permalink(); ?>">
                      <h2><?php the_title(); ?></h2>
                    </a>
                    <span><?php the_field('enName'); ?></span>
                  </div>
                </header>
                <div class="latestPosts__meta">
                  <ul>
                    <li>
                      <i class="bi bi-alarm-fill"></i>
                      <?php the_time('D d M Y'); ?>
                    </li>
                    <li>
                      <i class="bi bi-bar-chart-fill"></i>
                      <?= getPostViews(get_the_ID()); ?> 
                    </li>
                    <li>
                      <i class="bi bi-person-fill"></i>
                      <?php the_author(); ?>
                    </li>
                    <li>
                      <i class="bi bi-chat-quote-fill"></i>
                      <?php if (get_comments_number() == 0) {
                        echo 'بدون دیدگاه';
                      } else {
                        echo get_comments_number() . ' دیدگاه';
                      } ?>
                    </li>
                  </ul>
                </div>
                <div class="latestPosts__download">
                  <?php the_category(); ?>
                  <a class="latestPosts__download--link" href="<?php the_permalink(); ?>">دانلود کنید <i class="bi bi-download"></i></a>
                </div>
              </div>
            </div>
            <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 col-sm-4 order-1 order-sm-2 m-0 my-sm-2">
              <div class="latestPosts__left">
                <div class="thumbnail">
                  <?php the_post_thumbnail('home-tabs'); ?>
                  <?php the_post_thumbnail('home-tabs', array('class' => 'blur')); ?>
                </div>
              </div>
            </div>
          </div>
        <?php endwhile;
      endif;
      wp_reset_postdata();
      if ($pagination) :
        ?>
        <div class="pagination">
        <?php
        echo paginate_links(array(
          'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
          'total' => $query->max_num_pages,
          'current' => max(1, get_query_var('page')),
          'format' => '?paged=%#%',
          'show_all' => false,
          'type' => 'plain',
          'end_size' => 2,
          'mid_size' => 1,
          'prev_next' => true,
          'prev_text' => sprintf('<i></i> %1$s', __('قبلی', 'text-domain')),
          'next_text' => sprintf('%1$s <i></i>', __('بعدی', 'text-domain')),
          'add_args' => false,
          'add_fragment' => '',
        ));
      endif;
        ?>
        </div>
    </div>

<?php
  }
}
