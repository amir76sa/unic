<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TopCatsTab_widget extends \Elementor\Widget_Base
{

  /**
   * Get widget name.
   *
   * Retrieve oEmbed widget name.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget name.
   */
  public function get_name()
  {
    return 'TopCatsTab';
  }

  /**
   * Get widget title.
   *
   * Retrieve oEmbed widget title.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget title.
   */
  public function get_title()
  {
    return esc_html__('ویجت سایدبار:‌  تب برترین های دسته', 'elementor-oembed-widget');
  }

  /**
   * Get widget icon.
   *
   * Retrieve oEmbed widget icon.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget icon.
   */
  public function get_icon()
  {
    return 'eicon-tabs';
  }

  /**
   * Get custom help URL.
   *
   * Retrieve a URL where the user can get more information about the widget.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget help URL.
   */
  public function get_custom_help_url()
  {
    return 'https://developers.elementor.com/docs/widgets/';
  }

  /**
   * Get widget categories.
   *
   * Retrieve the list of categories the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget categories.
   */
  public function get_categories()
  {
    return ['basic'];
  }

  /**
   * Get widget keywords.
   *
   * Retrieve the list of keywords the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget keywords.
   */
  public function get_keywords()
  {
    return ['tab', 'homepage', 'index'];
  }

  /**
   * Register oEmbed widget controls.
   *
   * Add input fields to allow the user to customize the widget settings.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function register_controls()
  {

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('تنظیمات', 'elementor-oembed-widget'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $options = array();

    $args = array(
      'hide_empty' => false,
      'post_type'     => 'post',
      'taxonomy'  => 'category',

    );

    $categories = get_categories($args);

    foreach ($categories as $key => $category) {
      $options[$category->term_id] = $category->name;
    }


    $this->add_control(
      'title',
      [
        'label' => esc_html__('عنوان تب اول', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => 'برنامه های برتر',
      ]
    );
    $this->add_control(
      'title_2',
      [
        'label' => esc_html__('عنوان تب دوم', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => 'بازی های برتر',
      ]
    );

    $this->add_control(
      'category',
      [
        'label' => esc_html__('دسته بندی تب اول', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'multiple' => false,
        'options' => $options,
        'default' => [],
      ]
    );

    $this->add_control(
      'category_2',
      [
        'label' => esc_html__('دسته بندی تب دوم', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'multiple' => false,
        'options' => $options,
        'default' => [],
      ]
    );

    $this->add_control(
      'count',
      [
        'label' => esc_html__('تعداد مطالب برای نمایش', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا ۱۰', 'elementor-oembed-widget'),
        'default' => 10
      ]
    );


    $this->end_controls_section();
  }

  /**
   * Render oEmbed widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function render()
  {
    $settings = $this->get_settings_for_display();
    $title = $settings['title'];
    $title2 = $settings['title_2'];
    $count = $settings['count'];
    // if ($cat_name) :
?>
    <div class="widget widget_top_tabs">
      <ul class="nav nav-tabs" id="sideBarTab">
        <li class="nav-item">
          <button class="nav-link active" id="top_tab_1" data-bs-toggle="tab" data-bs-target="#top_1" type="button">
            <?php echo $title; ?>
          </button>
        </li>
        <li class="nav-item">
          <button class="nav-link" id="top_tab_2" data-bs-toggle="tab" data-bs-target="#top_2" type="button">
          <?php echo $title2; ?>
          </button>
        </li>
      </ul>
      <div class="tab-content" id="sideBarTabContent">
        <div class="tab-pane fade show active" id="top_1" role="tabpanel" aria-labelledby="nav-home-tab">
          <div class="widget__body">
            <ul>
              <?php
              $args = array(
                'post_type' => 'post',
                'posts_per_page' => $count,
                'cat' => $settings['category'],
                'order' => 'DESC',
                'meta_key'=>'post_views_count',
                'orderby'=>'meta_value_num',
              );

              $query = new WP_Query($args);
              if ($query->found_posts) {
                while ($query->have_posts()) {
                  $query->the_post();
              ?>
                  <li>
                    <figure class="widget__card">
                      <a href="<?php the_permalink(); ?>">
                        <div class="thumbnail">
                          <?php the_post_thumbnail('home-tabs'); ?>
                          <?php the_post_thumbnail('home-tabs', array('class' => 'blur')); ?>
                          <span class="top_badge"><?php echo $query->current_post+1; ?></span>
                        </div>
                        <figcaption class="info">
                          <h2><?php the_field('enName'); ?></h2>
                          <span class="faName"><?php the_field('faName'); ?></span>
                          <span class="rate">★ <?php the_field('post_score'); ?></span>
                        </figcaption>
                      </a>
                    </figure>
                  </li>
              <?php
                }
              }
              wp_reset_postdata();
              ?>
            </ul>
          </div>
        </div>
        <div class="tab-pane fade" id="top_2" role="tabpanel" aria-labelledby="nav-profile-tab">
        <div class="widget__body">
            <ul>
              <?php
              $args = array(
                'post_type' => 'post',
                'posts_per_page' => $count,
                'cat' => $settings['category_2'],
                'order' => 'DESC',
                'meta_key'=>'post_views_count',
                'orderby'=>'meta_value_num',
              );

              $query = new WP_Query($args);
              if ($query->found_posts) {
                while ($query->have_posts()) {
                  $query->the_post();
              ?>
                  <li>
                    <figure class="widget__card">
                      <a href="<?php the_permalink(); ?>">
                        <div class="thumbnail">
                          <?php the_post_thumbnail('home-tabs'); ?>
                          <?php the_post_thumbnail('home-tabs', array('class' => 'blur')); ?>
                          <span class="top_badge"><?php echo $query->current_post+1; ?></span>
                        </div>
                        <figcaption class="info">
                          <h2><?php the_field('enName'); ?></h2>
                          <span class="faName"><?php the_field('faName'); ?></span>
                          <span class="rate">★ <?php the_field('post_score'); ?></span>
                        </figcaption>
                      </a>
                    </figure>
                  </li>
              <?php
                }
              }
              wp_reset_postdata();
              ?>
            </ul>
          </div>
        </div>
      </div>

      
    </div>

<?php
    // endif;
  }
}
