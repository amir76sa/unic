<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class TextAds_widget extends \Elementor\Widget_Base
{

  /**
   * Get widget name.
   *
   * Retrieve oEmbed widget name.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget name.
   */
  public function get_name()
  {
    return 'TextAds';
  }

  /**
   * Get widget title.
   *
   * Retrieve oEmbed widget title.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget title.
   */
  public function get_title()
  {
    return esc_html__('ویجت سایدبار:‌  تبلیغات متنی', 'elementor-oembed-widget');
  }

  /**
   * Get widget icon.
   *
   * Retrieve oEmbed widget icon.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget icon.
   */
  public function get_icon()
  {
    return 'eicon-tabs';
  }

  /**
   * Get custom help URL.
   *
   * Retrieve a URL where the user can get more information about the widget.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget help URL.
   */
  public function get_custom_help_url()
  {
    return 'https://developers.elementor.com/docs/widgets/';
  }

  /**
   * Get widget categories.
   *
   * Retrieve the list of categories the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget categories.
   */
  public function get_categories()
  {
    return ['basic'];
  }

  /**
   * Get widget keywords.
   *
   * Retrieve the list of keywords the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget keywords.
   */
  public function get_keywords()
  {
    return ['tab', 'homepage', 'index'];
  }

  /**
   * Register oEmbed widget controls.
   *
   * Add input fields to allow the user to customize the widget settings.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function register_controls()
  {

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('تنظیمات بلاک', 'elementor-oembed-widget'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    // $options = array();

    // $args = array(
    //   'hide_empty' => false,
    //   'post_type'     => 'post',
    //   'taxonomy'  => 'category',

    // );

    // $categories = get_categories($args);

    // foreach ($categories as $key => $category) {
    //   $options[$category->term_id] = $category->name;
    // }


    $this->add_control(
      'title',
      [
        'label' => esc_html__('عنوان بخش', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => 'تبلیغات متنی',
      ]
    );

    $this->add_control(
      'list',
      [
        'label' => esc_html__('تبلیغ متنی', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => [
          [
            'name' => 'text',
            'label' => esc_html__('عنوان تبلیغ', 'plugin-name'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'placeholder' => esc_html__('عنوان تبلیغ', 'plugin-name'),
            'default' => esc_html__('متن ', 'plugin-name'),
          ],
          [
            'name' => 'desc',
            'label' => esc_html__('توضیحات تبلیغ', 'plugin-name'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'placeholder' => esc_html__('توضیحات تبلیغ', 'plugin-name'),
            'default' => esc_html__('توضیحات', 'plugin-name'),
          ],
          [
            'name' => 'link',
            'label' => esc_html__('لینک', 'plugin-name'),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => esc_html__('https://your-link.com', 'plugin-name'),
          ],
        ],
        'default' => [
          [
            'text' => esc_html__('خرید قالب دانلود از راست چین', 'plugin-name'),
            'desc' => esc_html__('متن توضیح', 'plugin-name'),
            'link' => 'https://www.rtl-theme.com/kelaketfilm-wordpress-theme/',
          ],
          [
            'text' => esc_html__('خرید قالب کلاکت فیلم از راست چین', 'plugin-name'),
            'desc' => esc_html__('متن توضیح', 'plugin-name'),
            'link' => 'https://www.rtl-theme.com/kelaketfilm-wordpress-theme/',
          ],
        ],
        'title_field' => '{{{ text }}}',
      ]
    );


    $this->end_controls_section();
  }

  /**
   * Render oEmbed widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function render()
  {
    $settings = $this->get_settings_for_display();
    $title = $settings['title'];
    // if ($cat_name) :
?>
    <div class="widget">
      <header class="widget__title">
        <h3><?php echo $title; ?></h3>
      </header>
      <div class="widget__body">
        <div class="text_ads">
          <ul>
            <?php foreach ($settings['list'] as $index => $item) : ?>
              <li>
                <?php
                if (!$item['link']['url']) {
                  echo $item['text'];
                } else {
                ?>
                  <a href="<?php echo esc_url($item['link']['url']); ?>">
                    <?php echo $item['text']; ?>
                    <span><?php echo $item['desc']; ?></span>
                  </a><?php } ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>

<?php
    // endif;
  }
}
