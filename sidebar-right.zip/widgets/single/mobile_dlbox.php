<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostMobileDLBox_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_mobile_dl_box';
  }

  public function get_title(){
    return esc_html__('ویجت دانلود باکس مخصوص سایت موبایل', 'unique');
  }

  public function get_icon(){
    return 'eicon-download-kit';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
<?php if(theme_options('download_type') == 'mobile'): ?>
  <!-- mobile dl box -->
  <div class="mobileDownload mb-3">
    <div class="mobileDownload__header">
      <h3>دانلود باکس</h3>
      <span>Download Center</span>
    </div>
    <div class="mobileDownload__inner">
      <div class="row">
        <div class="col-xl-7 col-lg-7 m-auto">
          <?php if(get_field('download')):
            while(have_rows('download')): the_row();
              if(get_sub_field('row_title')):?>
              <div class="dl_info"><?php the_sub_field('row_title'); ?></div>
              <?php endif; ?>
              <?php
              while (have_rows('download_row')) : the_row();
              $link = get_sub_field('download_link');
              $title = get_sub_field('download_link_title');
              $size = get_sub_field('size');
              
              ?>
              <div class="d-flex position-relative">
                <?php if( get_sub_field('updated') ):   ?>
                <div class="updated">
                  <span>بروز شده</span>
                </div>
                <?php endif; ?>
                <div class="download_item">
                  <?php if (get_sub_field('qr_code')) : ?>
                    <i class="bi bi-qr-code qr_icon position-relative" title="اسکن کنید">
                      <div class="qr_wrapper">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= $link ?>" width="150" height="150" alt="اسکن کنید <?php the_title(); ?>" />
                      </div>
                    </i>
                  <?php endif; ?>
                  <a href="<?= $link ?>"><i class="bi bi-cloud-arrow-down-fill"></i><?= $title ?> <?php if(get_sub_field('size')): ?><span><?= $size ?><?php endif; ?></span></a>
                </div>
              </div>
            <?php endwhile; ?>
            <?php endwhile;?>
          <?php endif; ?>
        </div>
        <div class="col-xl-12 col-lg-12 mt-5 dl_box_info">
          <ul>
            <li>
              <i class="bi bi-pencil"></i>
              <div class="single_info__meta--text">
                <div>آخرین آپدیت</div>
                <?php echo get_the_modified_time('F jS, Y'); ?>
              </div>
            </li>
            <?php if(get_field('required_android')): ?>
            <li>
              <i class="bi bi-gear"></i>
              <div class="single_info__meta--text">
                <div>اندروید مورد نیاز</div>
                <?php the_field('required_android') ?>
              </div>
            </li>
            <?php endif; ?>
            <?php if (get_field('price')) : ?>
              <li>
                <i class="bi bi-piggy-bank"></i>
                <div class="single_info__meta--text">
                  <div>قیمت در مارکت</div>
                  <?php the_field('price') ?>
                </div>
              </li>
            <?php endif; ?>
          <?php if (get_field('require_interner')) : ?>
            <li>
              <i class="bi bi-wifi"></i>
              <div class="single_info__meta--text">
                <div>نیازمند اینترنت</div>
                <?php the_field('require_interner') ?>
              </div>
            </li>
          <?php endif; ?>
          <?php if (get_field('developer')) : ?>
              <li>
                <i class="bi bi-code-slash"></i>
                <div class="single_info__meta--text">
                  <div>توسعه دهنده</div>
                  <?= str_replace('+', ' ', get_field('developer')) ?>
                </div>
              </li>
            <?php endif; ?>
            <?php if (get_field('installs')) : ?>
              <li>
                <i class="bi bi-globe"></i>
                <div class="single_info__meta--text">
                  <div>تعداد نصب</div>
                  <?php the_field('installs') ?>
                </div>
              </li>
            <?php endif; ?>
            <?php if (get_field('appId')) : ?>
              <li>
                <i class="bi bi-patch-question"></i>
                <div class="single_info__meta--text">
                  <div>پکیج نیم</div>
                  <?php the_field('appId') ?>
                </div>
              </li>
            <?php endif; ?>
            
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="mobileDownload__buttons">
    <?php if(get_field('playstore')): ?>
    <a href="<?php the_field('playstore'); ?>">گوگل پلی این برنامه  <img class="playstore" src="<?= get_template_directory_uri(); ?>/assets/images/playstore.svg" alt=""></a>
    <?php endif; ?>
    <button data-bs-toggle="modal" data-bs-target="#exampleModal">گزارش خرابی لینک</button>

    <a class="telegram" href="https://telegram.me/share/url?url=<?php the_permalink() ?>">اشتراک گذاری در تلگرام <i class="bi bi-telegram"></i></a>
    <a class="whatsapp" href="https://api.whatsapp.com/send/?phone&amp;text=&amp;<?php the_permalink() ?>app_absent=0"> اشتراک گذاری در واتس‌آپ <i class="bi bi-whatsapp"></i></a>

  </div>
  <?php endif; ?>
<?php
  }
}
