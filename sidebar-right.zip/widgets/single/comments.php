<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostComments_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_comments';
  }

  public function get_title(){
    return esc_html__('ویجت نظرات', 'unique');
  }

  public function get_icon(){
    return 'eicon-comments';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
<div class="single_post">
  <section class="comments">
    <header>
      <h3>ارسال دیدگاه</h3>
    </header>
    <?php
    $comments_count = wp_count_comments(get_the_ID());
    if (comments_open()) {
      comments_template();
    }
    ?>
  </section>
</div>
<?php
  }
}
