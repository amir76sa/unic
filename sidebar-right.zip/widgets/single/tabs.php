<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostTabs_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_tabs';
  }

  public function get_title(){
    return esc_html__('تب های مطلب', 'unique');
  }

  public function get_icon(){
    return 'eicon-tabs';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
<?php if (get_field('download') || get_field('system') || get_field('install_guide')) : ?>
  <section id="download_box" class="small_post">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <?php if (get_field('download') && theme_options('download_type') == 'pc') : ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#dl" type="button" role="tab" aria-controls="home" aria-selected="true">
            لینک های دانلود
          </button>
        </li>
      <?php endif; ?>
      <?php if (get_field('system')) : ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link <?php if(theme_options('download_type') == 'mobile'){ echo "active"; } ?>" id="profile-tab" data-bs-toggle="tab" data-bs-target="#system" type="button" role="tab" aria-controls="profile" aria-selected="false">
            سیستم مورد نیاز
          </button>
        </li>
      <?php endif; ?>
      <?php if (get_field('install_guide')) : ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#guide" type="button" role="tab" aria-controls="contact" aria-selected="false">
            راهنمای نصب
          </button>
        </li>
      <?php endif; ?>
    </ul>
    <div class="tab-content" id="myTabContent">
      <?php 
      if(theme_options('download_type') == 'pc'):
      if (get_field('download')) : ?>
        <div class="tab-pane fade show active" id="dl" role="tabpanel" style="min-height: 180px;" aria-labelledby="home-tab">
          <!-- tabConent 1 -->
          <?php
          if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
          } else {
            $ip = $_SERVER['REMOTE_ADDR'];
          }
          $details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
          if ($details->countryCode == 'IR') {
            $iran = true;
          } else {
            $iran = false;
          }
          if (theme_options('just_iran') == 'false' || $iran) :
          ?>
            <div class="row g-2 mt-3">
              <?php if(get_field('password')): ?>
                <span class="all_button">
                  password:
                  <?php the_field('password'); ?>
                  <i class="bi bi-lock-fill"></i>
                </span>
              <?php endif; ?>
              <div style="margin-bottom: 50px;" class="col-md-12 col-sm-12">
                <div class="d-flex align-items-start row">
                  <div class="nav flex-column dl-min nav-pills col-sm-3 col-12" id="v-pills-tab" role="tablist" aria-orientation="vertical">

                    <?php
                    //downloadbox
                    if (have_rows('download')) :
                      $i = 0;
                      while (have_rows('download')) : the_row();
                        $row_title = get_sub_field('row_title');
                    ?>

                        <button class="nav-link nav-dl <?php echo $i == 0 ? 'active' : ''  ?>" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-<?= $i; ?>" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
                          <?php $i++; ?>
                          <i class="bi bi-<?= get_sub_field('row_icon') ?>"></i>
                          <?= $row_title; ?>
                        </button>

                    <?php
                      endwhile;
                    endif;
                    ?>
                  </div>
                  <?php
                  //downloadbox
                  if (have_rows('download')) : ?>
                    <div class="tab-content dltab-content col-sm-9 col-12" id="v-pills-tabContent">

                      <?php $i = 0;
                      while (have_rows('download')) : the_row();
                        $row_title = get_sub_field('row_title'); ?>
                        <div class="tab-pane dl-pane fade <?php echo $i == 0 ? 'active show' : ''  ?>" id="v-<?= $i; ?>" role="tabpanel" aria-labelledby="v-pills-home-tab">
                          <?php $i++; ?>
                          <?php if (have_rows('download_row')) :
                            while (have_rows('download_row')) : the_row();
                              $link = get_sub_field('download_link');
                              $title = get_sub_field('download_link_title'); ?>
                                <div class="download_item">
                                  <a href="<?= $link ?>"><i class="bi bi-download"></i><?= $title ?></a>
                                  <?php if (get_sub_field('qr_code')) : ?>
                                    <i class="bi bi-qr-code qr_icon position-relative" title="اسکن کنید">
                                      <div class="qr_wrapper">
                                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= $link ?>" width="150" height="150" alt="اسکن کنید <?php the_title(); ?>" />
                                      </div>
                                    </i>
                                  <?php endif; ?>
                                </div>
                            <?php endwhile; ?>
                        </div>

                      <?php endif; ?>
                    <?php
                      endwhile; ?>
                    <div class="info_box">
                      <ul>
                        <li class="password">
                          <i class="bi bi-lock-fill"></i>
                          پسورد فایل: <?php the_field('password'); ?>
                        </li>
                        <?php foreach (theme_options('dl_box_links') as $item) : ?>
                          <li>
                            <a href="<?= $item['link'] ?>"><?= $item['name'] ?></a>
                          </li>
                        <?php endforeach; ?>
                        <li class="report">
                          <a href="#exampleModal" data-bs-toggle="modal" data-bs-target="#exampleModal">گزارش خرابی لینک و فایل ها</a>
                        </li>
                      </ul>
                    </div>
                    </div>

                  <?php endif; ?>

                </div>


              </div>
            </div>
          <?php else : ?>
            <div class="center">
              <div class="just_iran mt-3">
                <strong>نکته مهم:‌ </strong>خدمات این وبسایت برای کاربران داخل ایران می‌باشد. در صورت استفاده از VPN آنرا خاموش کرده و صفحه را رفرش کنید!
              </div>
            </div>
          <?php endif; ?>
          <!-- tabConent 1 -->
        </div>
      <?php endif; endif; ?>
      <div class="tab-pane fade <?php if(theme_options('download_type') == 'mobile'){ echo "show active"; } ?>" id="system" role="tabpanel" aria-labelledby="profile-tab">
        <!-- tabContent 2 -->
        <div class="row g-2 mt-3">
          <div class="">
            <?php
            the_field('system');
            ?>
          </div>
        </div>
        <!-- tabContent 2 -->
      </div>
      <div class="tab-pane fade" id="guide" role="tabpanel" aria-labelledby="contact-tab">
        <!-- tabContent 3 -->
        <div class="row g-2 mt-3">
          <div class="">
            <?php
            the_field('install_guide');
            ?>
          </div>
        </div>
        <!-- tabContent 3 -->
      </div>
    </div>
  </section>
<?php endif; ?>
<?php
  }
}
