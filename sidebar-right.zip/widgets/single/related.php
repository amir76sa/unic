<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostRelated_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_related';
  }

  public function get_title(){
    return esc_html__('ویجت مطالب مشابه', 'unique');
  }

  public function get_icon(){
    return 'eicon-product-related';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
    global $post;
?>
<h3 class="topCats__title mt-4">موارد مشابه</h3>

<div class="topCats">
  <div class="topCats__container swiper mySwiper">
    <div class="swiper-wrapper">
      <?php
      $related = get_posts(array('category__in' => wp_get_post_categories($post->ID), 'numberposts' => 10, 'post__not_in' => array($post->ID)));
      if ($related):
        foreach ($related as $post):
          setup_postdata($post);
      ?>
          <div class="swiper-slide">
            <article class="article">
              <a class="article__title--en" href="<?php the_permalink(); ?>" class=""><?php the_field('enName'); ?></a>
              <a href="<?php the_permalink(); ?>">
                <figure class="article__image">
                  <?php the_post_thumbnail('home-tabs'); ?>
                  <?php the_post_thumbnail('home-tabs', array('class' => 'blur')); ?>
                </figure>
              </a>
              <a class="article__title--fa" href="<?php the_permalink(); ?>"><?php the_field('faName'); ?></a>
              <div class="article__meta">
                <div class="article__stars">
                  <strong><?php the_field('post_score'); ?></strong>
                  <div class="Stars" style="--rating: <?php the_field('post_score'); ?>;" role="img" aria-label="Rating of this product is 2.3 out of 5."></div>
                </div>
              </div>
              <a class="abs" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"></a>
            </article>
          </div>
      <?php endforeach; endif;
      wp_reset_postdata(); ?>
    </div>
  </div>
</div>
<?php
  }
}