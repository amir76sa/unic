<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostChangelog_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_changelog';
  }

  public function get_title(){
    return esc_html__('changelog ویجت تغییرات مطلب', 'unique');
  }

  public function get_icon(){
    return 'eicon-exchange';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
  <?php if (get_field('changelog')) : ?>
    <div class="single_post">
      <div class="single_post__changelog">
        <header>
          <h3> تغییرات نسخه
            <?php the_field('version') ?>
          </h3>
        </header>
        <?php the_field('changelog'); ?>
      </div>
    </div>
  <?php endif; ?>
<?php
  }
}
