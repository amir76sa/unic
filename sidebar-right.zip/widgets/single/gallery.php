<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

class PostGallery_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_gallery';
  }

  public function get_title(){
    return esc_html__('ویجت گالری تصاویر مطلب', 'unique');
  }

  public function get_icon(){
    return 'eicon-instagram-gallery';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
<?php if ( get_field('gallery') || get_field('trailer') ) : ?>
  <section class="gallery mt-3">
    <header>
      <h3>گالری تصاویر</h3>
    </header>
    <div class="swiper mySwiper2">
      <div class="swiper-wrapper">
        <?php if( get_field('trailer') ): ?>
        <div class="swiper-slide">
          <a data-bs-toggle="modal" data-bs-target="#trailerModal" class="gallery_image trailer_image">
            <?php the_post_thumbnail() ?>
            <div class="gallery_overlay">
              <i class="bi bi-play-fill"></i>
            </div>
          </a>
        </div>
        <?php endif; ?>
        <?php if( get_field('gallery') ): foreach (get_field('gallery') as $index => $item) : ?>
          <div class="swiper-slide">
            <a data-elementor-lightbox-slideshow="gallery" data-elementor-lightbox-title="تصاویر <?php the_title(); ?>"  class="gallery_image" href="<?php echo $item['image']; ?>">
              <img alt="<?php the_title();?>" src="<?php echo $item['image']; ?>" />
              <div class="gallery_overlay">
                <i class="bi bi-arrows-angle-expand"></i>
              </div>
            </a>
          </div>
        <?php endforeach; endif; ?>
      </div>
      <div class="swiper-scrollbar"></div>
    </div>
  </section>
<?php endif; ?>
<?php
  }
}
