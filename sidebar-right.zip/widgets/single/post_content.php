<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostContent_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'eicon-post';
  }

  public function get_title(){
    return esc_html__('ویجت محتوای مطلب', 'unique');
  }

  public function get_icon(){
    return 'eicon-price-table';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
  <div class="single_post_text">
    <?php the_content(); ?>
  </div>
<?php
  }
}
