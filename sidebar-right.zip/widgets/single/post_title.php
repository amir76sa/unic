<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class PostTitle_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'post_title';
  }

  public function get_title(){
    return esc_html__('ویجت عنوان مطالب', 'unique');
  }

  public function get_icon(){
    return 'eicon-archive-title';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
?>
  <div class="single_post">
    <header>
      <h1><?php the_title(); ?></h1>
    </header>
  </div>
<?php
  }
}
