<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class SingleInfo_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'single_info';
  }

  public function get_title(){
    return esc_html__('ویجت اطلاعات مطالب', 'unique');
  }

  public function get_icon(){
    return 'eicon-info-box';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('عمومی', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
    global $post;
?>
  <div class="single_info elementor_single_rsidebar">
    <figure class="thumbnail">
      <?php the_post_thumbnail('single'); ?>
      <?php the_post_thumbnail('single', array('class' => 'blur')); ?>
    </figure>
    <span class="icon download_single bookmark  postFav-<?php echo $post->ID; ?> -click bi <?php echo is_favorite(get_current_user_id(), $post->ID) ? 'bi-bookmark-fill' : 'bi-bookmark' ?>" data-js="favorite" data-favorite="<?php echo $post->ID; ?>" data-user="<?php echo get_current_user_id(); ?>">
    <?php echo is_favorite(get_current_user_id(), $post->ID) ? 'حذف از علاقه مندی' : 'افزودن به علاقه مندی' ?>
    </span>
    <a href="#download_box" id="goto_dl" class="download_single">
      دانلود
      <i class="bi bi-download"></i>
    </a>
    <div class="single_info__meta">
      <ul>
        <li>
          <i class="bi bi-alarm"></i>
          <div class="single_info__meta--text">
            <div>تاریخ انتشار</div>
            <?php the_time('D d M Y'); ?>
          </div>
        </li>
        <li>
          <i class="bi bi-pencil"></i>
          <div class="single_info__meta--text">
            <div>آخرین آپدیت</div>
            <?php echo get_the_modified_time('F jS, Y'); ?>
          </div>
        </li>
        <li>
          <i class="bi bi-bar-chart"></i>
          <div class="single_info__meta--text">
            <div>تعداد بازدید</div>
            <?= getPostViews(get_the_ID()); ?>
          </div>
        </li>
        <?php if (get_field('version')) : ?>
          <li>
            <i class="bi bi-gear"></i>
            <div class="single_info__meta--text">
              <div>نسخه</div>
              <?php the_field('version') ?>
            </div>
          </li>
        <?php endif; ?>
        <?php if (get_field('required_android')) : ?>
          <li>
            <i class="bi bi-phone"></i>
            <div class="single_info__meta--text">
              <div>نسخه اندروید مورد نیاز</div>
              <?php the_field('required_android') ?>
            </div>
          </li>
        <?php endif; ?>
        <?php if (get_field('age')) : ?>
          <li>
            <i class="bi bi-exclamation-triangle"></i>
            <div class="single_info__meta--text">
              <div>رده سنی</div>
              <?php the_field('age') ?>
            </div>
          </li>
        <?php endif; ?>
        <li>
          <i class="bi bi-chat-quote"></i>
          <div class="single_info__meta--text">
            <div>نظرات</div>
            <?php if (get_comments_number() == 0) {
              echo 'بدون دیدگاه';
            } else {
              echo get_comments_number() . ' دیدگاه';
            } ?>
          </div>
        </li>
        <li>
          <i class="bi bi-card-text"></i>
          <div class="single_info__meta--text">
            <div>دسته بندی</div>
            <?php
            $categories = wp_get_post_categories(get_the_ID());
            foreach ($categories as $category) { ?>
              <a href="<?php echo get_category_link($category); ?>"><?php echo get_cat_name($category) ?> </a>
            <?php } ?>
          </div>
        </li>
      </ul>
    </div>
    <div class="single_category">
      <?php wp_nav_menu(array('theme_location' => 'singleCat-menu', 'container' => '', 'menu_class' => 'menunav')); ?>
    </div>
    <form class="search-form-single" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
      <div class="input-group">
        <input type="text" name="s" class="" placeholder="<?php esc_attr_e('جستجو', 'shop'); ?>" />
        <button type="submit" class="" name="submit"><i class="bi bi-search"></i></button>
      </div>
    </form>
  </div>
<?php
  }
}
