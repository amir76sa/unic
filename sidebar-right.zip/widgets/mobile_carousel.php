<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}


class MobileCarousel_widget extends \Elementor\Widget_Base
{

  public function get_name(){
    return 'mobile_carousel';
  }

  public function get_title(){
    return esc_html__('ویجت کروسل موبایل', 'unique');
  }

  public function get_icon(){
    return 'eicon-device-mobile';
  }

  public function get_categories(){
    return ['basic'];
  }

  protected function register_controls(){
    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('تنظیمات بلاک', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $options = array();

    $args = array(
      'hide_empty' => false,
      'post_type'     => 'post',
      'taxonomy'  => 'category',

    );

    $categories = get_categories($args);

    foreach ($categories as $key => $category) {
      $options[$category->term_id] = $category->name;
    }


    $this->add_control(
      'title',
      [
        'label' => esc_html__('عنوان بلاک', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا آخرین مطالب', 'elementor-oembed-widget'),
        'default' => 'آخرین مطالب'
      ]
    );

    $this->add_control(
      'category',
      [
        'label' => esc_html__('انتخاب دسته بندی', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'multiple' => false,
        'options' => $options,
        'default' => [],
      ]
    );

    $this->add_control(
      'number_posts',
      [
        'label' => esc_html__('تعداد مطالب برای نمایش', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا ۱۰', 'elementor-oembed-widget'),
      ]
    );

    $this->end_controls_section();

  }

  protected function render(){
    $settings = $this->get_settings_for_display();
    $number_posts = $settings['number_posts'];
    $cat_id = $settings['category'];
    if (!empty($cat_id)) {
      $paged = (get_query_var('page')) ? get_query_var('page') : 1;
      $cat_name = get_cat_name($settings['category']);
      $args = array(
        'post_type' => 'post',
        'posts_per_page' => $number_posts,
        'cat' => $cat_id,
        'order' => 'DESC',
        'paged' => $paged,
      );
    } else {
      $paged = (get_query_var('page')) ? get_query_var('page') : 1;
      $args = array(
        'post_type' => 'post',
        'posts_per_page' => $number_posts,
        'order' => 'DESC',
        'paged' => $paged,
      );
    }
?>
<div class="mobile_carousel">
  <div class="mobile_carousel__heading d-flex justify-content-between align-items-center">
    <h3><?php echo $settings['title']; ?></h3>
    <a href="<?php echo get_category_link( $settings['category'] ) ?>">
      <?php _e('مشاهده همه', 'unique') ?>
    </a>
  </div>

  <div class="mobile_carousel__body">
    <?php
    $query = new WP_Query($args);
    if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
    ?>
      <article class="article">
        <a class="article__title--en" href="<?php the_permalink(); ?>" class=""><?php the_field('enName'); ?></a>
        <a href="<?php the_permalink(); ?>">
          <figure class="article__image">
            <?php the_post_thumbnail('home-tabs'); ?>
            <?php the_post_thumbnail('home-tabs', array('class' => 'blur')); ?>
          </figure>
        </a>
        <a class="article__title--fa" href="<?php the_permalink(); ?>"><?php the_field('faName'); ?></a>
        <div class="article__meta">
          <div class="time">
            <?php the_modified_time('M');  ?>  <?php the_modified_time('d'); ?> 
          </div>
        </div>
        <a class="abs" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"></a>
      </article>
    <?php endwhile;
    endif;
    wp_reset_postdata(); ?>
  </div>
</div>
<?php
  }
}
