<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class AdsBlock_widget extends \Elementor\Widget_Base
{

  /**
   * Get widget name.
   *
   * Retrieve oEmbed widget name.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget name.
   */
  public function get_name()
  {
    return 'adsBlock';
  }

  /**
   * Get widget title.
   *
   * Retrieve oEmbed widget title.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget title.
   */
  public function get_title()
  {
    return esc_html__('ویجت تبلیغات بلاکی', 'unique');
  }

  /**
   * Get widget icon.
   *
   * Retrieve oEmbed widget icon.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget icon.
   */
  public function get_icon()
  {
    return 'eicon-price-table';
  }

  /**
   * Get custom help URL.
   *
   * Retrieve a URL where the user can get more information about the widget.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget help URL.
   */
  public function get_custom_help_url()
  {
    return 'https://developers.elementor.com/docs/widgets/';
  }

  /**
   * Get widget categories.
   *
   * Retrieve the list of categories the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget categories.
   */
  public function get_categories()
  {
    return ['basic'];
  }

  /**
   * Get widget keywords.
   *
   * Retrieve the list of keywords the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget keywords.
   */
  public function get_keywords()
  {
    return ['ads', 'homepage', 'index'];
  }

  /**
   * Register oEmbed widget controls.
   *
   * Add input fields to allow the user to customize the widget settings.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function register_controls()
  {

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('محتوا', 'unique'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $this->add_control(
      'list',
      [
        'label' => esc_html__('تبلیغ متنی', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => [
          [
            'name' => 'text',
            'label' => esc_html__('عنوان تبلیغ', 'plugin-name'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'placeholder' => esc_html__('عنوان تبلیغ', 'plugin-name'),
            'default' => esc_html__('متن ', 'plugin-name'),
          ],
          [
            'name' => 'desc',
            'label' => esc_html__('عکس تبلیغ', 'plugin-name'),
            'type' => \Elementor\Controls_Manager::TEXT,
            'placeholder' => esc_html__('لینک عکس تبلیغ وارد کنید', 'plugin-name'),
            'default' => esc_html__('', 'plugin-name'),
          ],
          [
            'name' => 'link',
            'label' => esc_html__('لینک', 'plugin-name'),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => esc_html__('https://your-link.com', 'plugin-name'),
          ],
        ],
        'default' => [
          [
            'text' => esc_html__('خرید قالب دانلود از راست چین', 'plugin-name'),
            'desc' => esc_html__('http://localhost/download/wp-content/uploads/2022/01/Salatin-W-1.jpg', 'plugin-name'),
            'link' => 'https://www.rtl-theme.com/kelaketfilm-wordpress-theme/',
          ],
          [
            'text' => esc_html__('خرید قالب کلاکت فیلم از راست چین', 'plugin-name'),
            'desc' => esc_html__('http://localhost/download/wp-content/uploads/2022/01/Salatin-W-1.jpg', 'plugin-name'),
            'link' => 'https://www.rtl-theme.com/kelaketfilm-wordpress-theme/',
          ],
        ],
        'title_field' => '{{{ text }}}',
      ]
    );
    


    $this->end_controls_section();





    $this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'استایل', 'sepidar' ),
				'tab' => Elementor\Controls_Manager::TAB_STYLE,
			]
		);

    $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .ads_blockk',
			]
		);

    $this->add_control(
			'item_padding',
			[
				'label' => esc_html__( 'پدینگ', 'sepidar' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ads_blockk' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

    $this->add_control(
			'item_margin',
			[
				'label' => esc_html__( 'مارجین', 'sepidar' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ads_blockk' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

    $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .ads_blockk__title',
			]
		);

    $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .ads_blockk',
			]
		);

    $this->end_controls_section();
  }

  /**
   * Render oEmbed widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function render()
  {
    $settings = $this->get_settings_for_display();

?>
    <div class="row ads_blockk">
      <?php foreach ($settings['list'] as $index => $item) : ?>
        <div class="col">
          <a href="<?php echo esc_url($item['link']['url']); ?>">
            <img src="<?= $item['desc'] ?>" alt="">
            <div class="ads_blockk__title"><?php echo $item['text']; ?></div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
<?php
  }
}
