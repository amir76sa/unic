<?php
if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class shopCarousel_widget extends \Elementor\Widget_Base
{

  // public function __construct($data = [], $args = null)
  // {
  //   parent::__construct($data, $args);

  //   wp_register_script('script-handle',  get_template_directory_uri().'/assets/js/swiper.min.js', ['elementor-frontend'], '1.0.0', true);
  // }


  // public function get_script_depends()
  // {
  //   return ['script-handle'];
  // }


  /**
   * Get widget name.
   *
   * Retrieve oEmbed widget name.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget name.
   */
  public function get_name()
  {
    return 'shopCarousel';
  }

  /**
   * Get widget title.
   *
   * Retrieve oEmbed widget title.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget title.
   */
  public function get_title()
  {
    return esc_html__('کروسل محصولات فروشگاه', 'elementor-ads-widget');
  }

  /**
   * Get widget icon.
   *
   * Retrieve oEmbed widget icon.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget icon.
   */
  public function get_icon()
  {
    return 'eicon-basket-solid';
  }

  /**
   * Get custom help URL.
   *
   * Retrieve a URL where the user can get more information about the widget.
   *
   * @since 1.0.0
   * @access public
   * @return string Widget help URL.
   */
  public function get_custom_help_url()
  {
    return 'https://developers.elementor.com/docs/widgets/';
  }

  /**
   * Get widget categories.
   *
   * Retrieve the list of categories the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget categories.
   */
  public function get_categories()
  {
    return ['basic'];
  }

  /**
   * Get widget keywords.
   *
   * Retrieve the list of keywords the oEmbed widget belongs to.
   *
   * @since 1.0.0
   * @access public
   * @return array Widget keywords.
   */
  public function get_keywords()
  {
    return ['post', 'top', 'best'];
  }

  /**
   * Register oEmbed widget controls.
   *
   * Add input fields to allow the user to customize the widget settings.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function register_controls()
  {

    $this->start_controls_section(
      'content_section',
      [
        'label' => esc_html__('تنظیمات بلاک', 'elementor-ads-widget'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

    $options = array();

    $args = array(
      'hide_empty' => false,
      'post_type'     => 'post',
      'taxonomy'  => 'category',

    );

    // $categories = get_the_terms('download_category');
    $categories = get_categories('taxonomy=download_category&type=download&hide_empty=0'); 

    foreach ($categories as $key => $category) {
      $options[$category->term_id] = $category->name;
    }


    $this->add_control(
      'title',
      [
        'label' => esc_html__('عنوان بلاک', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا آخرین محصولات فروشگاه', 'elementor-oembed-widget'),
        'default' => 'آخرین محصولات فروشگاه'
      ]
    );

    $this->add_control(
      'category',
      [
        'label' => esc_html__('انتخاب دسته بندی', 'plugin-name'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'multiple' => false,
        'options' => $options,
        'default' => [],
      ]
    );

    $this->add_control(
      'number_posts',
      [
        'label' => esc_html__('تعداد مطالب برای نمایش', 'elementor-oembed-widget'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => esc_html__('مثلا ۱۰', 'elementor-oembed-widget'),
      ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
			'section_styles',
			[
				'label' => esc_html__( 'استایل', 'sepidar' ),
				'tab' => Elementor\Controls_Manager::TAB_STYLE,
			]
		);

    $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .topCats',
			]
		);

    $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background_item',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .topCats .abs',
			]
		);

    $this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'sepidar' ),
				'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
					'{{WRAPPER}} .topCats .article a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .topCats .article strong' => 'color: {{VALUE}}',
				],
			]
		);

    $this->end_controls_section();


  }

  /**
   * Render oEmbed widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.0.0
   * @access protected
   */
  protected function render()
  {
    $settings = $this->get_settings_for_display();
    $number_posts = $settings['number_posts'];
    $title = $settings['title'];
    $cat_id = $settings['category'];
    if (!empty($cat_id)) {
      $paged = (get_query_var('page')) ? get_query_var('page') : 1;
      $cat_name = get_cat_name($settings['category']);
      $args = array(
        'post_type' => 'download',
        'posts_per_page' => $number_posts,
        'tax_query' => array(
          array(
            'taxonomy' => 'download_category',
            'field' => 'id',
            'terms' => $cat_id,
          )
        ),
        'order' => 'DESC',
        'paged' => $paged,
      );
    } else {
      $paged = (get_query_var('page')) ? get_query_var('page') : 1;
      $args = array(
        'post_type' => 'download',
        'posts_per_page' => $number_posts,
        'order' => 'DESC',
        'paged' => $paged,
      );
    }
?>

    <h3 class="topCats__title"><?php echo $title; ?></h3>

    <div class="topCats">
      <div class="topCats__container swiper mySwiper">
        <div class="swiper-wrapper">
          <?php
          $query = new WP_Query($args);
          if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
          ?>
              <div class="swiper-slide">
                <div class="article">
                  <a class="article__title--en" href="<?php the_permalink(); ?>">
                    <?php the_field('faName'); ?>
                  </a>
                  <a href="<?php the_permalink(); ?>">
                    <figure class="article__image">
                      <?php the_post_thumbnail('home-tabs'); ?>
                      <?php the_post_thumbnail('home-tabs', array('class' => 'blur')); ?>
                    </figure>
                  </a>
                  <a class="article__title--fa" href="<?php the_permalink(); ?>">
                  <?php edd_price(get_the_ID()); ?>
                  </a>
                  <div class="article__meta">
                    <div class="article__stars">
                      <strong><?php the_field('post_score'); ?></strong>
                      <div class="Stars" style="--rating: <?php the_field('post_score'); ?>;" role="img" aria-label="Rating of this product is 2.3 out of 5."></div>
                    </div>
                  </div>
                  <a class="abs" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"></a>
                </div>
              </div>
          <?php endwhile;
          endif;
          wp_reset_postdata(); ?>
        </div>
        <!-- <div class="swiper-pagination"></div> -->
      </div>
    </div>
<?php
  }
}
