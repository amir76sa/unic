jQuery(document).ready(function ($) {

  var LoadingMarkUp = '<div class="loadingBalls">' + '<div class="ball"></div>' + '<div class="ball"></div>' + '<div class="ball"></div>' + '</div>';

  var vertical_swiper = new Swiper(".vertical_swiepr", {
    direction: "vertical",
    slidesPerView: 9,
    noSwiping: true,
    noSwipingClass: 'swiper-slide',
    // spaceBetween: 1,
    // loop: true,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
  });

  var swiper = new Swiper(".mySwiper", {
    slidesPerGroup: 1,
    // loop: true,
    slidesPerView: 1,
    spaceBetween: 10,
    autoplay: {
      delay: 5000,
    },
    // init: false,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
      300: {
        slidesPerView: 1,
        spaceBetween: 10,
      },
      640: {
        slidesPerView: 2,
        spaceBetween: 10,
      },
      940: {
        slidesPerView: 3,
        spaceBetween: 10,
      },

      1024: {
        slidesPerView: 4,
        spaceBetween: 10,
      },

      1440: {
        slidesPerView: 5,
        spaceBetween: 10,
      },
    },
  });

  var swiper2 = new Swiper(".mySwiper2", {
    // slidesPerView: 3,
    slidesPerView: 'auto',
    spaceBetween: 10,
    freeMode: true,
    scrollbar: {
      el: ".swiper-scrollbar",
      // hide: true,
      draggable: true,
    },
  });

  function setFavorite(userid, favoriteid) {
    var favorite_field = jQuery(".postFav-" + favoriteid);
    //  var favorite_field = jQuery('[data-js="favorite"]');
    var favorite_label = jQuery('[data-js="favorite_label"]');
    jQuery.ajax({
      url: ajaxurl,
      data: {
        action: "setfavorite",
        userid: userid,
        favoriteid: favoriteid,
        nonce: nonce,
      },
      dataType: "json",
      type: "POST",
      cache: false,

      beforeSend: function (xhr) {
        favorite_field
          .removeClass("bi-bookmark-fill bi-bookmark")
          .addClass("bi-three-dots");
        favorite_field.html('صبر کنید')

      },

      success: function (data) {
        var icon = data.is_favorite ? "bi-bookmark-fill" : "bi-bookmark";

        favorite_field.removeClass("bi-three-dots");
        favorite_field.addClass(icon);

        favorite_label.html("");
        favorite_label.append(data.favorites_num);
        var toast = jQuery('#toast');
        if (data.error) {
          toast.html(data.message);
          toast.addClass('toast_error');
          toast.fadeIn('fast');
          setTimeout(function () {
            toast.fadeOut('fast');
            toast.removeClass('toast_error');
            toast.html('');
          }, 4000);
          favorite_field.html('افزودن به علاقه مندی')
        } else {
          if (data.is_favorite) {
            favorite_field.html('حذف از علاقه مندی')
          } else {
            favorite_field.html('افزودن به علاقه مندی')
          }
          toast.html(data.message);
          toast.fadeIn('fast');
          setTimeout(function () {
            toast.fadeOut('fast');
            toast.html('');
          }, 4000);
        }
      },
    });
  }

  jQuery("[data-js=favorite]").click(function () {
    var favoriteid = jQuery(this).data("favorite");
    var userid = jQuery(this).data("user");
    setFavorite(userid, favoriteid);
  });

  jQuery(".removeFav").click(function () {
    var postid = jQuery(this).data("id");
    var userid = jQuery(this).data("user");
    if (confirm('آیا مطمئن هستید میخواهید این فیلم را حذف کنید؟')) {
      jQuery.ajax({
        url: ajaxurl,
        data: {
          action: "removeFav",
          userid: userid,
          favoriteid: postid,
          nonce: nonce,
        },
        dataType: "json",
        type: "POST",
        cache: false,

        success: function (data) {
          console.log(data);
          if (data.success) {
            jQuery(".p" + data.id).slideUp("fast");
          }
        },
      });
    }
  });

  $(".wg-ajax-submit").on('click', function (e) {
    var admin_url = wg_ajax_login_object.ajax_url;
    var $this = $(this);

    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: admin_url,
      data: {
        'action': 'wg_ajax_login_handler', //calls wp_ajax_nopriv_ajaxlogin
        'wg_username': $('.wg-username-email').val(),
        'wg_password': $('.wg-password').val(),
        'nonce': $('#wg_ajax_nonce').val()
      },
      beforeSend: function () {
        // Show user a message that details are being checked
        $this.html(LoadingMarkUp);
      },
      success: function (data) {
        $this.html('ورود');
        if (data.loggedin == true) {
          // Show success message if user details exist
          $('.wg-msg').html('<div class="success">' + wg_ajax_login_object.successMessage + '</div>');
          // Create timer to refresh page after successfull login
          setTimeout(function () {
            document.location.href = wg_ajax_login_object.redirectUrl;
          }, 2000);
        } else if (data.loggedin == false) {
          // Show failure message if user details doesn't exist
          $('.wg-msg').html('');

          for (var prop in data.errors) {
            console.log(prop, data.errors[prop][0])
            $('.wg-msg').append('<div class="error">' + data.errors[prop][0] + '</div>')
          }
        }
      }
    });
    e.preventDefault();
  });


  $(".wg-ajax-register-submit").on('click', function (e) {
    var admin_url = wg_ajax_login_object.ajax_url;
    var $this = $(this);
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: admin_url,
      data: {
        'action': 'wg_ajax_register_handler',
        'wg_username': $('.wgr-username').val(),
        'wg_email': $('.wgr-email').val(),
        'wg_password': $('.wgr-password').val(),
        'wg_password_again': $('.wgr-password-again').val(),
        'nonce': $('#wg_ajax_nonce2').val()
      },
      beforeSend: function () {
        // Show user a message that details are being checked
        $this.html(LoadingMarkUp);
      },
      success: function (data) {
        $this.html('عضویت');
        if (data.register == true) {
          // Show success message if user details exist
          $('.wgr-msg').html('<div class="success">' + wg_ajax_login_object.regSuccessMessage + '</div>');
          // Create timer to refresh page after successfull login
          setTimeout(function () {
            document.location.href = wg_ajax_login_object.redirectUrl;
          }, 2000);
        } else if (data.register == false) {
          $('.wgr-msg').html('');

          if (data.error) {
            $('.wgr-msg').html('<div class="error">' + data.error + '</div>');
          }
          for (var prop in data.errors) {
            console.log(prop, data.errors[prop][0])
            $('.wgr-msg').append('<div class="error">' + data.errors[prop][0] + '</div>')
          }
        }
      }
    });
    e.preventDefault();
  });



  $('.search_triger, .mobile_nav_search').on('click', function (e) {
    e.preventDefault();
    MobileMenu.css("right", "-100%");
    MobileMenuHolder.css("visibility", "hidden");
    $('#modal_search').fadeToggle('fast');
  })
  $('.close_modal').on('click', function (e) {
    $('#modal_search').fadeOut('fast');
  })

  $(".darkMode").click(function () {
    $("html").toggleClass("dark");
    if ($("html").hasClass("dark")) {
      localStorage.setItem("theme", "dark");
      $(".dark_toggle").removeClass("bi-moon");
      $(".dark_toggle").addClass("bi-sun");
    } else {
      localStorage.setItem("theme", "light");
      $(".dark_toggle").removeClass("bi-sun");
      $(".dark_toggle").addClass("bi-moon");
    }
  });


  $("#download_box .dltab-content").css("min-height", $(".dl-min").height());
  $(document).on("click", function () {
    $(".qr_wrapper").hide("fast");
  });
  $(".qr_icon").on("click", function (event) {
    event.stopPropagation();
    var self = this;

    $(".qr_wrapper").not($(self).children()).hide("fast");
    $(self).children().toggle("fast");
  });
  $("#goto_dl").on("click", function (event) {
    event.preventDefault();
    document.getElementById("download_box").scrollIntoView();
  });

  var submenu = $(".single_category .sub-menu").hide();

  $(".single_category li > a").click(function (e) {
    if ($(this).next().is("ul")) {
      e.preventDefault();
      if ($(this).parent().hasClass("child-minus")) {
        $(this).parent().removeClass("child-minus");
        $(this).next().slideUp("500");
      } else {
        submenu.slideUp("500");
        $(".single_category li").removeClass("child-minus");
        $(this).parent().addClass("child-minus");
        $(this).next().slideDown("500");
      }
      return false;
    }
  });
  $(window).on("scroll", function () {
    if ($(this).scrollTop() > 100) {
      $(".go_up").css("right", "0");
    } else {
      $(".go_up").css("right", "-100px");
    }
  });
  $(".go_up").on("click", function (e) {
    e.preventDefault();
    $("html, body").animate({ scrollTop: 0 }, 100);
  });

  var MobileMenuIcon = $(".mobileNavBtn");
  var MobileMenu = $(".float_menu");
  var MobileMenuHolder = $(".float_menu_holder");

  $(document).on('mouseup', (e) => {
    if (!MobileMenu.is(e.target) && MobileMenu.has(e.target).length === 0) {
      MobileMenu.css("right", "-100%");
      MobileMenuHolder.css("visibility", "hidden");
    }
  });

  MobileMenuIcon.on('click', function () {
    MobileMenu.css("right", "0px");
    MobileMenuHolder.css("visibility", "visible");
  });

});
